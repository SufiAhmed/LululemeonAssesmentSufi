//
//  SegmentControl.swift
//  LululemonTechAssesmentSufiAhmed
//
//  Created by Sufiyan Ahmed on 5/10/23.
//

import Foundation


enum SegControl: String {
    case alphabetic = "Alphabetic"
    case date = "Creation Time"
}
