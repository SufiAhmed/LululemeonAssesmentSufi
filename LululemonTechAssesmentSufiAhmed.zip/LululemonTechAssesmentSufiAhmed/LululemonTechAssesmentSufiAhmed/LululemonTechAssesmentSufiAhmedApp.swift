//
//  LululemonTechAssesmentSufiAhmedApp.swift
//  LululemonTechAssesmentSufiAhmed
//
//  Created by Sufiyan Ahmed on 5/10/23.
//

import SwiftUI

@main
struct LululemonTechAssesmentSufiAhmedApp: App {

    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
